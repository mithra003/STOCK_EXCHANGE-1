package com.stockmarket.service.impl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.stockmarket.model.UserRequestModel;
import com.stockmarket.repository.UserRepository;
import com.stockmarket.service.UserService;

@Service
public class UsersService implements UserService  {

	@Autowired
	private UserRepository repo;
	@Autowired
	private BCryptPasswordEncoder  bCryptPasswordEncoder;
   

	
	public void userService(BCryptPasswordEncoder  bCryptPasswordEncoder ) {
		this.bCryptPasswordEncoder = bCryptPasswordEncoder;
	}
	
	public void post(UserRequestModel user) {
		
        user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
        
        user.setUserId("kjkajgdwfku");
		repo.save(user);
		
		
		
	}


	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		
		UserRequestModel user = repo.findByEmail(username);
		if(user == null) throw new UsernameNotFoundException(username);
		return new User(user.getEmail(), user.getPassword(), true, true, true, true, new ArrayList<>());
	}

	public UserRequestModel  getUserDetailsByEmail(String userName) {
		UserRequestModel user = repo.findByEmail(userName);
		if(user == null) throw new UsernameNotFoundException(userName);
		return user;
	}
	


}
