package com.stockmarket.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.stockmarket.model.UserRequestModel;

public interface UserService extends UserDetailsService{
	UserRequestModel getUserDetailsByEmail(String userName);
}
