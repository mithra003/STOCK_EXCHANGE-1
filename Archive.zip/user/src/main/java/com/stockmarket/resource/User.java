package com.stockmarket.resource;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stockmarket.model.UserRequestModel;

import com.stockmarket.service.impl.UsersService;

@RestController
@RequestMapping("/users/register")
public class User {
	@Autowired
	private UsersService userService;
	@PostMapping
	public void registerCompany(@Valid @RequestBody UserRequestModel registeration) {
		userService.post(registeration);
    }

}
