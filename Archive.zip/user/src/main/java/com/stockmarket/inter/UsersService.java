package com.stockmarket.inter;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.stockmarket.model.UserRequestModel;

public interface UsersService extends UserDetailsService {
	UserRequestModel getUserDetailsByEmail(String userName);
}
