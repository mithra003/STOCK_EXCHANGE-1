package com.stockmarket.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@SpringBootApplication
@ComponentScan("com.stockmarket")
@ComponentScan("com.stockmarket.security")
@EnableMongoRepositories("com.stockmarket.repository")
public class UserApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserApplication.class, args);
	}
	
	@Bean	
	public BCryptPasswordEncoder  bCryptPasswordEncoder() {
		
		return new BCryptPasswordEncoder();
	}

}
