package com.stockmarket.repository;

import org.springframework.data.mongodb.repository.MongoRepository;


import com.stockmarket.model.UserRequestModel;

public interface UserRepository extends MongoRepository<UserRequestModel, String>{

	UserRequestModel findByEmail(String username);

}
