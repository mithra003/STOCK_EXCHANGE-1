package com.stockmarket.companies.convertor;

import org.modelmapper.ModelMapper;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.stockmarket.companies.model.Registration;
import com.stockmarket.document.UserRegistration;

@Component 
public class RegistrationDtoConvertor implements Converter<UserRegistration, Registration> {

	@Override
	public Registration convert(UserRegistration source) {
		ModelMapper modelMapper = new ModelMapper();
		Registration userData = modelMapper.map(source, Registration.class);
		return userData;
	}

}
