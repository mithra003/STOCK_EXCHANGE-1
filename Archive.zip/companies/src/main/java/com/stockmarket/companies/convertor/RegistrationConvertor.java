package com.stockmarket.companies.convertor;
import org.modelmapper.ModelMapper;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.stockmarket.companies.model.Registration;
import com.stockmarket.document.UserRegistration;

@Component
public class RegistrationConvertor implements Converter<Registration, UserRegistration>{

	@Override
	public UserRegistration convert(Registration source) {
		ModelMapper modelMapper = new ModelMapper();
		UserRegistration userData = modelMapper.map(source, UserRegistration.class);
		return userData;
	}

	

}
