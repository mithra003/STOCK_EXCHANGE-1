package com.stockmarket.companies.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stock.market.companies.exception.CompanyNotFoundException;
import com.stockmarket.companies.convertor.RegistrationConvertor;
import com.stockmarket.companies.convertor.RegistrationDtoConvertor;
import com.stockmarket.companies.model.Registration;
import com.stockmarket.companies.repository.CompanyRepository;
import com.stockmarket.document.UserRegistration;

@Service
public class CompanyService {

	@Autowired
	CompanyRepository repository;
	
	@Autowired 
	RegistrationConvertor registrationConvertor;
	
	@Autowired
	RegistrationDtoConvertor registrationDtoConvertor;

	public List<Registration> getAllCompanies() {
		List<Registration> result = null;
		List<UserRegistration> companyData = repository.findAll();
		if(companyData.size()>0) {
		ModelMapper modelMapper = new ModelMapper();
	    result = companyData.stream().map(company -> modelMapper.map(company, Registration.class))
				.collect(Collectors.toList());
		}
		return result;
	}

	public void registerCompany(Registration registration) {
		UserRegistration userData = registrationConvertor.convert(registration);
		repository.save(userData);
	}

	public Registration companyDetailsById(String code) {
		Optional<UserRegistration> companyDetails = repository.findById(code);
		if (companyDetails.isPresent()) {
			UserRegistration companyData = companyDetails.get();
			return registrationDtoConvertor.convert(companyData);
		}
		else 
			throw new CompanyNotFoundException("The company details not found");
	}

	public void removeCompany(String id) {
		
	  repository.deleteById(id);

	}

}
