package com.stockmarket.companies.model;

import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
public class Registration {
	
	@NotNull(message = "client.error.company-code-cannot-be-null")
	private String companyCode;

	@NotNull(message = "client.error.company-name-cannot-be-null")
	private String companyName;
	
	@NotNull(message = "client.error.company-ceo-name-cannot-be-null")
	private String companyCEO;
	
	@NotNull(message = "client.error.website-cannot-be-null")
	private String website;
	
	@NotNull(message = "client.error.turnover-cannot-be-null")
	private double turnover;
	
	@NotNull(message = "client.error.stock-exchange-listed-cannot-be-null")
	private String stockExchangeListed;

}
