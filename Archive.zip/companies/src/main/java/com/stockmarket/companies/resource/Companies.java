package com.stockmarket.companies.resource;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stockmarket.companies.model.Registration;
import com.stockmarket.companies.service.CompanyService;

@RestController
@RequestMapping("/api/v1.0/market/company")
public class Companies {
	
	@Autowired
	private CompanyService companyService;
	
	@GetMapping("/info/{companycode}")
	public Registration getCompanyDetailsByCode(@PathVariable("companycode") String companyCode) {
		return companyService.companyDetailsById(companyCode);
	}
	
	@PostMapping("/register")
	public void registerCompany(@Valid @RequestBody Registration registeration) {
		companyService.registerCompany(registeration);
    }
	
	@GetMapping("/info/getall")
	public List<Registration> getAllCompanies() {
		return companyService.getAllCompanies();
	}
	
	@DeleteMapping("/delete/{companycode}")
	public void removeCompany(@PathVariable("companycode") String companyCode) {	
		companyService.removeCompany(companyCode);
	}
	

}
