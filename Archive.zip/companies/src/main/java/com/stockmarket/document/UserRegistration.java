package com.stockmarket.document;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;


@Data
@Document(collection = "stockmarket")
public class UserRegistration {
	
	    @Id
		private String companyCode;

		private String companyName;
		
		private String companyCEO;
		
		private String website;
		
		private double turnover;
		
		private String stockExchangeListed;

}
