package com.stockmarket.companies.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.stockmarket.companies.model.Registration;
import com.stockmarket.companies.repository.CompanyRepository;
import com.stockmarket.document.UserRegistration;

@ExtendWith(SpringExtension.class)
public class CompanyServiceTest {
	
	@InjectMocks
	CompanyService companyService;
	@Mock
	CompanyRepository companyRepository;
	
	@Test
	public void shouldGetAllCompanies() {
		UserRegistration registration = new UserRegistration();
		registration.setCompanyCEO("Murugesan");
		registration.setCompanyCode("GFD");
		registration.setStockExchangeListed("yes");
		registration.setTurnover(1000);
		registration.setWebsite("www.india.com");
		List<UserRegistration> result = new ArrayList<>();
		result.add(registration);
		when(companyRepository.findAll()).thenReturn(result);
		assertTrue(companyService.getAllCompanies().toString().contains("Murugesan"));
	}
	
	@Test
	public void shouldReturnEmptyList() {
		UserRegistration registration = new UserRegistration();
		List<UserRegistration> result = new ArrayList<>();
		result.add(registration);
		
		Registration userRegistration = new Registration();
		List<Registration> userList = new ArrayList<>();
		userList.add(userRegistration);
		
		when(companyRepository.findAll()).thenReturn(result);
		assertEquals(companyService.getAllCompanies().toString(),userList);
	}

}
