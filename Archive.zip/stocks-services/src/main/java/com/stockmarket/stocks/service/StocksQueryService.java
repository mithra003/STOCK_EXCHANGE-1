package com.stockmarket.stocks.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.stockmarket.stocks.DTO.CompanyData;
import com.stockmarket.stocks.DTO.Registration;
import com.stockmarket.stocks.client.CompanyRestConsumer;
import com.stockmarket.stocks.document.StockPrice;
import com.stockmarket.stocks.entity.StockPrices;
import com.stockmarket.stocks.repository.StocksRepository;
import com.stockmarket.stocks.resource.StocksCommandController;


@Service
public class StocksQueryService {
	
private static final Logger LOGGER = LoggerFactory.getLogger(StocksCommandController.class);
	
	@Autowired(required=true)
	private StocksRepository stocksRepository;
	
	@Autowired 
	private CompanyRestConsumer companyRestConsumer;
	
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-d");
	public List<StockPrice> getStockPrice(String companyCode, String startDate, String endDate) {
	     List<StockPrice> stockPrice = stocksRepository.findAll();
	     if(!stockPrice.isEmpty()) {
	    	 return stockPrice.stream().filter(e -> this.isWithinRange(e.getDate(), startDate, endDate)).collect(Collectors.toList());
	     }
	     return stockPrice;
	}
	
	
	private boolean isWithinRange(String currentDate,String startDate, String endDate) {
		  LocalDate start = LocalDate.parse(startDate, formatter);
		  LocalDate end = LocalDate.parse(endDate, formatter);
		  LocalDate current = LocalDate.parse(currentDate, formatter);
	      return !(current.isBefore(start) || current.isAfter(end));
	}
	
	@KafkaListener(topics = "cqrs", groupId = "stockmarket", containerFactory = "userKafkaListenerFactory")
		public void postUserTweets(StockPrices price) {
		LOGGER.info("Data sync is triggered", price);
		StockPrice stockPrice = new StockPrice();
		  stockPrice.setCompanyCode(price.getCompanyCode());
		  stockPrice.setDate(price.getDate());
		  stockPrice.setPrice(price.getPrice());
		  stockPrice.setId(price.getId());
		  stocksRepository.save(stockPrice);
		}
	
	public CompanyData getStockDetailsWithCompanyInfo(String companyCode) {
		LOGGER.info("Get stock with company details ", companyCode);
		CompanyData companyData = new CompanyData();
		Registration companyDetails = companyRestConsumer.getCompanyDetails(companyCode);
		Optional<StockPrice> price = stocksRepository.findById(companyCode);
		if(price.isPresent()) {
			LOGGER.info("The price data is present", price);
			companyData.setPrice(price.get());
		}
		
		companyData.setRegistration(companyDetails);
		
		return companyData;
		
	}

}
