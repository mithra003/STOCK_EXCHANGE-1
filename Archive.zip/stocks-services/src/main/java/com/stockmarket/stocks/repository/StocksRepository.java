package com.stockmarket.stocks.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.stockmarket.stocks.document.StockPrice;

@Repository
public interface StocksRepository extends MongoRepository<StockPrice, String>{

}
