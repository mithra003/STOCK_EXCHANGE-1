package com.stockmarket.stocks.DTO;

import com.stockmarket.stocks.document.StockPrice;

import lombok.Data;


@Data
public class CompanyData {
	
	Registration registration;
	
	StockPrice price;

}
