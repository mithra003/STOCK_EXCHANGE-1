package com.stockmarket.stocks.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.stockmarket.stocks.entity.StockPrices;
@Repository
public interface StocksCommandRepository extends JpaRepository<StockPrices,  String>{

}
