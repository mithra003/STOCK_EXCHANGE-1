package com.stockmarket.stocks.DTO;
import lombok.Data;

@Data
public class Registration {
	
	private String companyCode;

	private String companyName;
	
	private String companyCEO;
	
	private String website;
	
	private double turnover;
	
	private String stockExchangeListed;

}
