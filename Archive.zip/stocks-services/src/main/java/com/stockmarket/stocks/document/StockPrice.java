package com.stockmarket.stocks.document;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Data
@Document(collection = "stocks")
public class StockPrice {
	
	@Id
    String id;
	
	String companyCode;
	
	String date;
	
	double price;

}
