package com.stockmarket.stocks.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class StockPrices {
	@Id
	@Column
	private String id;
	
	@Column
	String companyCode;
	@Column
	String date;
	@Column
	double price;

}
