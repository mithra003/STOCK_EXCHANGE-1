package com.stockmarket.stocks.client;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.stockmarket.stocks.DTO.Registration;

@FeignClient(name="companies")
public interface CompanyRestConsumer {

	@GetMapping("/info/{companycode}")
	 public Registration getCompanyDetails(@PathVariable String id);
}
