package com.stockmarket.stocks.DTO;

import lombok.Data;

@Data
public class Price {
	double price;
}
