package com.stockmarket.stocks.resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.stockmarket.stocks.DTO.Price;
import com.stockmarket.stocks.service.StocksCommandService;

@RestController
@RequestMapping("/api/v1.0/market/stock")
public class StocksCommandController {
	private static final Logger LOGGER = LoggerFactory.getLogger(StocksCommandController.class);
	
	@Autowired
	private StocksCommandService stocksCommandService;
	
	@PostMapping("/add/{companyCode}")
	public void postStocks(@PathVariable("companyCode") String companyCode, @RequestBody Price price) {
		LOGGER.info("the add method triggered");
		stocksCommandService.saveStockPrice(companyCode, price.getPrice());
	}
	
}
