package com.stockmarket.stocks.service;

import java.time.LocalDate;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.stockmarket.stocks.entity.StockPrices;
import com.stockmarket.stocks.repository.StocksCommandRepository;



@Service
public class StocksCommandService {
	private static final Logger LOGGER = LoggerFactory.getLogger(StocksCommandService.class);
	@Autowired(required=true)
	private StocksCommandRepository stocksRepository;
	
	@Autowired
	KafkaTemplate<String, StockPrices> kafkaTemplate;

	public void saveStockPrice(String code, double price) {
		StockPrices stockPrice = new StockPrices();
		LocalDate localDate = LocalDate.now();
	    stockPrice.setCompanyCode(code);
	    stockPrice.setId(UUID.randomUUID().toString());
	    stockPrice.setPrice(price);
	    stockPrice.setDate(localDate.toString());
	    stocksRepository.save(stockPrice);
	    LOGGER.info("The data is saved successfully ", stockPrice);
	    triggerDataSync(stockPrice);
	    LOGGER.info("The data sync is triggered successfully ", stockPrice);
	}
	
	private void triggerDataSync(StockPrices stockPrice) {
		kafkaTemplate.send("cqrs", "Message", stockPrice);
	}

}
