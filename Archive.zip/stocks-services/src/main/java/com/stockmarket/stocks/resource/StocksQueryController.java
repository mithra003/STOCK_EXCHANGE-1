package com.stockmarket.stocks.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stockmarket.stocks.DTO.CompanyData;
import com.stockmarket.stocks.document.StockPrice;
import com.stockmarket.stocks.service.StocksQueryService;

@RestController
@RequestMapping("/api/v1.0/market/stock")
public class StocksQueryController {
	
	@Autowired
	private StocksQueryService stocksQueryService;
	
	@GetMapping("/get/{companyCode}/{startDate}/{endDate}")
	public List<StockPrice> getStocks(@PathVariable("companyCode") String companyCode,@PathVariable("startDate") String startDate,@PathVariable("endDate") String endDate) {
		return stocksQueryService.getStockPrice(companyCode, startDate, endDate);
		
	}
	
	@GetMapping("/get/{companyCode}/all")
	public CompanyData getCompanyData(@PathVariable("companyCode") String companyCode) {
		return stocksQueryService.getStockDetailsWithCompanyInfo(companyCode);
	}

}
